export class Circle{
    createdDate:Date;
    creatorId:string;
    circleName:string
}


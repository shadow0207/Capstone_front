import { Injectable } from '@angular/core';
import { Message, MESSAGES } from './message/message';

@Injectable()
export class MessageService {

  constructor() { }

  getMessage():Message[]{
    return MESSAGES;
  }
}
